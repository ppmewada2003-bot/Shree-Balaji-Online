SHREE BALAJI ONLINE - STARTER PWA
=================================

This is a simple installable website (PWA), not a Play Store APK.
WhatsApp and phone buttons are set to 9754125312.
Location: Akodiya, Shajapur, MP.

PUBLISH FREE USING GITHUB PAGES
1. On a computer or Android browser, create/sign in to a GitHub account at https://github.com
2. Create a NEW PUBLIC repository named: shree-balaji-online
3. Choose Add file > Upload files.
4. Upload ALL files and folders from this ZIP (index.html, manifest.json, sw.js, icons folder).
5. Press Commit changes.
6. Open repository Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch "main" and folder "/ (root)", then Save.
9. Wait a few minutes. GitHub will show your website address, usually:
   https://YOUR-USERNAME.github.io/shree-balaji-online/
10. Open that address on Android Chrome. Tap the three-dot menu > Install app
    (or Add to Home screen).

IMPORTANT
- The site needs HTTPS to install as a PWA; GitHub Pages provides HTTPS.
- This starter app only shows services and opens WhatsApp/call. It does not process
  Aadhaar/PAN applications, payments, tickets, insurance purchases, or collect orders
  automatically.
- Never ask customers to send Aadhaar numbers, OTPs, bank PINs or passwords through WhatsApp.
- Replace service labels, prices, product photos and links after verifying what you actually offer.
- For a custom domain, Play Store listing, payment gateway, or real backend, additional setup/costs may apply.
